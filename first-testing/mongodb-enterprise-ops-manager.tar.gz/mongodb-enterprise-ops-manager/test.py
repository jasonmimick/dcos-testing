import urllib
from urllib import error 
from urllib import request
import time

WAIT_FOR_CONNECTION_SLEEP_SECONDS=10
def wait_for_connection(url):

    while True:
        try:
            print('wait_for_connection: url=%s' % url)
            response = urllib.request.urlopen(url,timeout=1)
            print('wait_for_connection: OK')
            return
        except urllib.error.URLError:
            print('wait_for_connection: FAIL')
            time.sleep(WAIT_FOR_CONNECTION_SLEEP_SECONDS)
            pass


wait_for_connection("http://google.com")
wait_for_connection("http://serpifdsifn.dfosidnf")
